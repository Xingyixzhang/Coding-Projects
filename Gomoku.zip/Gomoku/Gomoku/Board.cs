﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Gomoku
{
    class Board
    {
        private static readonly Point NoMatchNode = new Point(-1, -1);
        private static readonly int OFFSET = 75;
        private static readonly int NodeRadius = 10;
        private static readonly int NodeDistance = 75;
        private Piece[,] pieces = new Piece[9, 9];

        public bool CanBePlaced(int x, int y)
        {
            Point node = FindTheClosetNode(x, y);
            if (node == NoMatchNode) return false;
            if (pieces[node.X, node.Y] != null) return false;
            return true;
        }
        public Piece PlacePiece(int x, int y, PieceType type)
        {
            Point node = FindTheClosetNode(x, y);
            if (node == NoMatchNode) return null;
            if (pieces[node.X, node.Y] != null) return null;

            Point formPos = ConvertToFormPos(node);

            if (type == PieceType.BLACK) pieces[node.X, node.Y] = new Black(formPos.X, formPos.Y);
            else if (type == PieceType.WHITE) pieces[node.X, node.Y] = new White(formPos.X, formPos.Y);

            return pieces[node.X, node.Y];
        }
        private Point ConvertToFormPos(Point node)
        {
            Point formPosition = new Point();
            formPosition.X = node.X * NodeDistance + OFFSET;
            formPosition.Y = node.Y * NodeDistance + OFFSET;
            return formPosition;
        }
        private Point FindTheClosetNode(int x, int y)
        {
            int nodeX = FindTheClosetNode(x);
            if (nodeX == -1) return NoMatchNode;
            int nodeY = FindTheClosetNode(y);
            if (nodeY == -1) return NoMatchNode;
            
            return new Point(nodeX, nodeY);
        }
        private int FindTheClosetNode(int pos)
        {
            if (pos < OFFSET - NodeRadius) return -1;

            pos -= OFFSET;
            int quo = pos / NodeDistance;
            int remainder = pos % NodeDistance;

            if (remainder <= NodeRadius) return quo;
            else if (remainder >= NodeDistance - NodeRadius) return quo + 1;
            else return -1;
        }
        //public bool CheckWin(Point node)
        //{
            
        //}
    }
}
